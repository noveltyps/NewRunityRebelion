Welcome to the official Release of Runity.

Hosted and released by Adam/Naimur Rahman

This server has been worked on for months.
By the following Users.

- Adam (me) Founder/Head Developer, starting this project late 2017.
- Ethan (developer) Worked on it for 3-4 Months.
- Red Bracket Worked on it for 3-4 Months.
- Harryl/Nerik.
- Teek/DrHenny.


To setup this server, simply place it on eclipse.

<b>How to setup the server?</b>

Right click the file in project menu.
Go down to --> configure --> Add Gradle Nature.

This code needs improvements, it was a great learning tool and was fun while it lasted.


<b>How to use the runelite client?</b>

Install Lombok.jar
Run Lombok.jar
Relaunch eclipse.
Reload libraries.
Add required dependencies to gradle.

My Rune-server: https://www.rune-server.ee/members/bitshifting/

If you do use this, I would respect that you give appropriate credits.
It's only right, alot of my time went into this server.

Thank you to all the staff members and beta testers that helped us patch over 2000+ Bugs with this server.
This isn't the only repository, we have in total over 3500+ Commits distributed over multiple repo's



I will be frequently updating this server as bugs are found.
